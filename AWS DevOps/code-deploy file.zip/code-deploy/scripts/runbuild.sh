#!/bin/bash
aws s3 cp s3://coderepobuckets3/demo-build-project/my-app /tmp/
